from tkinter import *
from tkinter import font
import tkinter.messagebox
import http.client
from xml.dom.minidom import parse, parseString
import requests, xmltodict
from bs4 import BeautifulSoup
import lxml
from PIL import Image

from datetime import date, datetime
from functools import partial
import os
import sys
from tkcalendar import Calendar, DateEntry
from tkinter import ttk
from tkinter import scrolledtext
import tkinter as tk
from PIL import Image, ImageTk, ImageOps, ImageFilter




