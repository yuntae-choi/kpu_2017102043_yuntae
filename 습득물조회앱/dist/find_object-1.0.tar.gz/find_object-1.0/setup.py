from distutils.core import setup

setup(name='find_object',
      version='1.0',

      py_modules=['find_object','stdafx','mysmtplib','tele','notic']
      )
